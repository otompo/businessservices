import React from "react";
import AdminLayout from "../../layout/AdminLayout";
import css from "./ManageSettings.module.scss";

const ManageSettings = () => {
  return (
    <AdminLayout>
      <div className={css.container}>
        <div className={css.leftcolumn}>
          <p>Manage Settings</p>
        </div>
        <div className={css.rightcolumn}></div>
      </div>
    </AdminLayout>
  );
};

export default ManageSettings;
